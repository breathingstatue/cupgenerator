CupGenerator v.1.3
Added missing parts of Random Cars function to the UI's cup load
32-bit version support
Now Time Trial and Practice Star completion unlocks CustomObtain normally
Fixed Adding and Removing Stages in the Cups panel

CupGenerator v.1.2
Updates to UI

CupGenerator v.1.1
- Update Function
- Updates to UI

CupGenerator v.1.0

- The program is CupGen.exe
- my Win11 warned for AutoInjector.exe - its purpose is to inject the mod .dll file into rvgl.exe

======================================================================

[INSTRUCTIONS:]

Set the RVGL root folder. Set the profile you're going to use in RVGL.
Now... Leave the CupGen running in the background and the new params will work in rvgl.exe

(Works only with RVGL Launcher and with the lastest RVGL version: 23.1030a1)

=======================================================================

[NEW PARAMETERS:]

ObtainCustom ; same as Obtain but for Custom Cups / Tracks
Opponents ; choose who you play against
RandomCars ; cup uses random cars
Joker ; all cars are same as you (same as cheat code JOKER)

-----------------------------------------------------------------------

[EXAMPLES:]

ObtainCustom 1 - set the custom Cup that must be completed before Unlocking
ObtainCustom 2 - set the tracks that must have practice star collected
ObtainCustom 3 - set the tracks that must have time-trial (normal) completed
ObtainCustom 4 - set the tracks that must have single player mode completed

Opponents carfoldername(s) - (separated by space)

for e.g.:
NumCars 4
Opponents toyeca humma beatall

RandomCars 1 stock main bonus - you can use these three params to decide the lottery pool

Joker 1 carfoldername - (car must be specified already in the CupGen)
you can use Joker together with RandomCars parameter

=======================================================================

- by Theman
1st of September 2025